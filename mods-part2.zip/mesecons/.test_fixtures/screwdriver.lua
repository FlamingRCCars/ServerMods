mineunit:set_current_modname("screwdriver")

screwdriver = {}

screwdriver.ROTATE_FACE = 1
screwdriver.ROTATE_AXIS = 2
