cx384's inventorybags mod

This mod adds bags.

License:

	Copyright (C) 2017 cx384
	
	Code:
	
		Maciej Kasatkin / RealBadAngel ( GNU LGPLv2+ ) ( https://github.com/minetest-mods/technic/blob/master/technic_chests/register.lua ):
			file: /inventorybags/sort_inventory_function.lua
	
		Everything else:
		cx384 ( GNU GPLv3  )
	
	Sounds:
	
		j1987 ( CC0 1.0 ) ( http://www.freesound.org/people/j1987/sounds/79385/ ):
		(split)
			inventorybags_open_bag.ogg
			inventorybags_close_bag.ogg
			
		sqeeeek ( CC0 1.0 ) ( http://www.freesound.org/people/sqeeeek/sounds/381854/ ):
			inventorybags_open_suitcase.ogg
			
		Eelke ( CC BY 3.0 ) ( http://www.freesound.org/people/Eelke/sounds/176176/ ):
		(split)
			inventorybags_open_zipper.ogg
			inventorybags_close_zipper.ogg
		
		nebulousflynn ( CC BY 3.0 ) ( http://www.freesound.org/people/nebulousflynn/sounds/220941/ ):
		(parts)
			inventorybags_open_plastic_bag.ogg
			inventorybags_close_plastic_bag.ogg
	
		outroelison ( CC0 1.0 ) ( http://www.freesound.org/people/outroelison/sounds/150950/ ):
		(split)
			inventorybags_open_teleportation_bag.ogg
			inventorybags_close_teleportation_bag.ogg
	
		RADIY ( CC BY 3.0 ) ( http://www.freesound.org/people/RADIY/sounds/213148/ ):
			inventorybags_bud_upgrade.ogg
	
		MastersDisaster ( CC BY 3.0 ) ( http://www.freesound.org/people/MastersDisaster/sounds/218115/ ):
			inventorybags_bud_extract.ogg
	
		whouser ( CC BY-NC 3.0 ) ( http://www.freesound.org/people/whouser/sounds/377795/ ):
			inventorybags_sleeping.1.ogg
	
		monkslut ( CC BY 3.0 ) ( http://www.freesound.org/people/monkslut/sounds/35208/ ):
			inventorybags_sleeping.2.ogg
	
		Robinhood76 ( CC BY-NC 3.0 ) ( http://www.freesound.org/people/Robinhood76/sounds/68458/ ):
			inventorybags_sleeping.3.ogg
	
		Fortyseven203 ( CC0 1.0 ) ( http://www.freesound.org/people/Fortyseven203/sounds/240139/ ):
			inventorybags_sleeping.4.ogg
	
		stransky ( CC0 1.0 ) ( http://www.freesound.org/people/stransky/sounds/380065/ ):
		(part)
			inventorybags_spinning_wheel.ogg
	
		mar1o ( CC BY 3.0 ) ( http://www.freesound.org/people/mar1o/sounds/164117/ ):
		(part)
			inventorybags_loom.ogg
		
		Cyril Laurier ( CC BY 3.0 ) ( http://www.freesound.org/people/Cyril%20Laurier/sounds/17645/ ) :
		(split)
			inventorybags_wind.1.ogg
			inventorybags_wind.2.ogg
		
		Everything else:
		cx384 ( CC-BY-SA-4.0 )
		
	Textures:
	
		Everything else:
		cx384 ( CC-BY-SA-4.0 )
	
