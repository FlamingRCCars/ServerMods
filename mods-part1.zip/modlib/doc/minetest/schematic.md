# Schematic

A schematic format with support for metadata and baked light data.
