Online Shop v1.0


DESCRIPTION
==============================
Allows players to buy and trade anywhere.


LICENSE
==============================
Copyright (C) 2020 LC Creations - LGPL v2.1


INSTALLATION
==============================
Place this folder inside Minetest Directory>mods


SUPPORT
==============================
Report bugs here on GitHub
