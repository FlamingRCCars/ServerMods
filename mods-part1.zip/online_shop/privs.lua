minetest.register_privilege("online_shop_admin", {
	description = "Player can edit and destroy any shop server.",
	give_to_singleplayer = false,
})