# Unified Inventory Themes

This minetest mod adds a modern theme to the unified_inventory mod.

TODO: add more themes.

## License

Code: MIT (by threehymns and wsor)

Assets: CC0 (threehymns)

Icons: CC0 (mostly from https://www.kenney.nl/assets/game-icons)