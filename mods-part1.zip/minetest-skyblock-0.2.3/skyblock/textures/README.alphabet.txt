[Mod] Alphabet [alphabet]

Homepage: http://minetest.net/forum/viewtopic.php?id=2312
License: GNU GPL

Contributors:
cactuz_pl

Description:
This simple mod adds blocks with letters (A-Z, a-z) numbers and symbols.

To select letter place dirt in place marked in green, place it in the order that corresponds to this letter in Braille.
http://en.wikipedia.org/wiki/Braille 

Then place wood in red box - for upper case, or in yellow box - for lower case.
To select number place dirt in green box (in Braille, A for 1, B for 2 ... J for 0) and put wood in blue box.
To select symbol place dirt in green box and cobble in blue box.
A for !
B for @
C for #
D for $
E for %
F for ^
G for &
H for *
I for ( 
J for )
K for ' 
L for \ 
M for : 
N for , 
O for = 
P for -
Q for + 
R for ?
S for " 
T for / 
U for _
V for . (dot)
Example: (for plus)
(dirt,dirt, ---)
(dirt,dirt, ---)
(dirt,---, cobble)
Space (white block):
(dirt,dirt, ---)
(dirt,dirt, ---)
(dirt,dirt, ---)